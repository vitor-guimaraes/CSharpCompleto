﻿namespace CSharpCompleto
{
    public class Pessoa
    {
        public int Idade;
        public string Nome;
    }
}
